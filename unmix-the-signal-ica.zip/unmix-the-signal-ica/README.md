# Unmix the Signal (ICA)

A runnable educational project that mixes several clean audio sources with a custom mixing matrix, then separates them using **PCA whitening + FastICA implemented from scratch** (NumPy is used for matrix operations; no scikit-learn or ICA library).

## What it does
- Generates three reproducible example sources (speech-like tone/noise, music-like melody, and ambient sound) so the project runs without downloading audio.
- Optionally loads your own WAV source files.
- Centers the mixtures and performs PCA whitening with covariance and eigendecomposition.
- Implements symmetric FastICA from scratch using a `tanh` nonlinearity.
- Exports clean source WAVs, mixed WAVs, separated WAVs, and comparison plots.
- Evaluates separation using absolute correlation and scale-aligned SDR; source order and sign/scale ambiguity are handled in evaluation.
- Includes a PCA-vs-ICA discussion and experiment notes.

## Requirements
Python 3.10+ recommended.

## Run on Windows (VS Code)
```powershell
cd unmix-the-signal-ica
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python run_ica.py
```

Results are written to `outputs/`:
- `sources/` — clean source WAV files
- `mixtures/` — mixed audio WAV files
- `separated/` — recovered audio WAV files
- `plots/` — waveforms, correlation matrix, and metric chart
- `metrics.json` — numerical evaluation

Listen to any WAV file using your normal media player. The source generator is deliberately synthetic and suitable for testing the pipeline; it is not a real speech/music dataset.

## Use your own recordings
Put at least 2 and at most 5 mono WAV files in `custom_sources/`. Use the same sample rate and similar duration. Then run:
```powershell
python run_ica.py --custom
```
The script crops sources to a common length and resamples them to the configured sample rate if needed (requires `scipy`). If you only provide one custom source, the program stops with a helpful error. Sources should be reasonably independent and non-Gaussian for ICA to work well.

## Core algorithm
1. Center observed mixture channels.
2. Compute covariance matrix.
3. Eigen-decompose covariance, sort eigenvalues descending.
4. Whiten: `Z = D^(-1/2) E^T X`.
5. Run symmetric FastICA fixed-point iterations:
   - `W_new = E[g(WZ) Z^T]/N - diag(E[g'(WZ)]) W`
   - orthogonalize `W_new` using symmetric decorrelation.
6. Recover components and evaluate against originals.

## Why ICA instead of PCA?
PCA decorrelates signals and orders directions by variance, but does not generally make them statistically independent. ICA uses higher-order statistics (here, the nonlinearity `tanh`) to seek independent, non-Gaussian components. Whitening makes the covariance identity, reducing the remaining search to an orthogonal rotation.

## Central Limit Theorem intuition
A mixture of independent sources tends to be more Gaussian than the individual sources. ICA looks for projections that are maximally non-Gaussian (using a contrast based on `tanh`) to recover source-like components. This is an intuition and not a guarantee; real-world sources can violate ICA assumptions.

## Evaluation caveats
- Correlation is reported as absolute value because sign is arbitrary.
- Each separated component is matched to the best original source by absolute correlation (brute-force permutations, up to 5 sources).
- SDR is scale-aligned least-squares SDR, a useful educational metric but not a full BSS Eval implementation.
- Source scaling, sign and order are fundamentally ambiguous in ICA.
- Good separation requires a square, full-rank mixing matrix and statistically independent sources.

## Limitations
- This is a teaching/demo project, not a production audio restoration tool.
- Generated sample sources are synthetic; real speech/music/ambient sources often need careful preprocessing.
- The project implements FastICA itself and does not call a third-party ICA implementation.
