from __future__ import annotations
import argparse
import itertools
import json
from pathlib import Path

import numpy as np
import soundfile as sf
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.signal import resample_poly

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "outputs"
SAMPLE_RATE = 16000
DURATION_SECONDS = 8
RNG_SEED = 7


def normalize_audio(x: np.ndarray, peak: float = 0.85) -> np.ndarray:
    x = np.asarray(x, dtype=np.float64).reshape(-1)
    x = x - np.mean(x)
    max_abs = np.max(np.abs(x)) if x.size else 0.0
    if max_abs > 1e-12:
        x = x * (peak / max_abs)
    return x


def save_wav(path: Path, audio: np.ndarray, sample_rate: int = SAMPLE_RATE) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    sf.write(str(path), np.asarray(audio, dtype=np.float32), sample_rate, subtype="PCM_16")


def make_synthetic_sources(sample_rate: int, seconds: int) -> tuple[np.ndarray, list[str]]:
    """Create reproducible non-identical sources without external audio downloads."""
    rng = np.random.default_rng(RNG_SEED)
    n = sample_rate * seconds
    t = np.arange(n, dtype=np.float64) / sample_rate

    # Speech-like: changing harmonic formants gated by syllable-like envelopes.
    syllable_rate = 3.2
    gate = (np.sin(2 * np.pi * syllable_rate * t) > -0.25).astype(float)
    gate = np.convolve(gate, np.ones(301) / 301, mode="same")
    f0 = 115 + 18 * np.sin(2 * np.pi * 0.22 * t)
    phase = 2 * np.pi * np.cumsum(f0) / sample_rate
    speech_like = sum((1 / k) * np.sin(k * phase + 0.12 * k) for k in range(1, 9))
    speech_like *= gate * (0.6 + 0.4 * np.sin(2 * np.pi * 0.7 * t) ** 2)

    # Music-like: a deliberately uneven plucked melody/chord pattern.
    notes = np.array([220.0, 277.18, 329.63, 277.18, 246.94, 293.66, 369.99, 293.66])
    beat = np.floor(t * 2).astype(int) % len(notes)
    freq = notes[beat]
    phase_music = 2 * np.pi * np.cumsum(freq) / sample_rate
    envelope = np.exp(-((t * 2) % 1.0) * 3.0)
    music_like = envelope * (np.sin(phase_music) + 0.35 * np.sin(2 * phase_music) + 0.15 * np.sin(3 * phase_music))
    music_like += 0.18 * np.sin(2 * np.pi * 110 * t) * (0.5 + 0.5 * np.sin(2 * np.pi * 0.5 * t))

    # Ambient-like: colored noise plus slow modulation and a distant low hum.
    white = rng.normal(0, 1, n)
    kernel = np.ones(180) / 180
    low_noise = np.convolve(white, kernel, mode="same")
    ambient_like = 0.8 * low_noise + 0.12 * rng.normal(size=n)
    ambient_like *= 0.75 + 0.25 * np.sin(2 * np.pi * 0.13 * t)
    ambient_like += 0.2 * np.sin(2 * np.pi * 58 * t)

    sources = np.vstack([normalize_audio(s) for s in (speech_like, music_like, ambient_like)])
    return sources, ["speech_like", "music_like", "ambient_like"]


def load_custom_sources(folder: Path, sample_rate: int) -> tuple[np.ndarray, list[str]]:
    paths = sorted(folder.glob("*.wav"))
    if len(paths) < 2:
        raise ValueError(f"Put at least 2 mono WAV files in {folder}")
    if len(paths) > 5:
        raise ValueError("Use 2 to 5 source WAV files for this demo.")
    loaded = []
    names = []
    for path in paths:
        audio, sr = sf.read(str(path), always_2d=False)
        if audio.ndim == 2:
            audio = np.mean(audio, axis=1)
        if sr != sample_rate:
            # Rational polyphase resampling avoids depending on external ffmpeg.
            from math import gcd
            g = gcd(int(sr), int(sample_rate))
            audio = resample_poly(audio, sample_rate // g, int(sr) // g)
        loaded.append(np.asarray(audio, dtype=np.float64))
        names.append(path.stem)
    min_len = min(map(len, loaded))
    if min_len < sample_rate:
        raise ValueError("Audio files must each be at least one second long.")
    sources = np.vstack([normalize_audio(x[:min_len]) for x in loaded])
    return sources, names


def symmetric_decorrelation(w: np.ndarray) -> np.ndarray:
    """Project rows of W onto the orthogonal group via eigendecomposition."""
    gram = w @ w.T
    eigvals, eigvecs = np.linalg.eigh(gram)
    eigvals = np.maximum(eigvals, 1e-12)
    inv_sqrt = eigvecs @ np.diag(1.0 / np.sqrt(eigvals)) @ eigvecs.T
    return inv_sqrt @ w


def pca_whiten(x: np.ndarray, eps: float = 1e-10) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Whiten channels using centered covariance eigendecomposition."""
    x = np.asarray(x, dtype=np.float64)
    x_centered = x - np.mean(x, axis=1, keepdims=True)
    covariance = (x_centered @ x_centered.T) / x_centered.shape[1]
    eigvals, eigvecs = np.linalg.eigh(covariance)
    order = np.argsort(eigvals)[::-1]
    eigvals, eigvecs = eigvals[order], eigvecs[:, order]
    if np.any(eigvals <= eps):
        raise ValueError("Mixture covariance is rank-deficient; use independent sources and a full-rank mixing matrix.")
    whitening = np.diag(1.0 / np.sqrt(eigvals)) @ eigvecs.T
    z = whitening @ x_centered
    return z, whitening, x_centered


def fastica_from_scratch(z: np.ndarray, max_iter: int = 1000, tol: float = 1e-6,
                         random_state: int = 11) -> tuple[np.ndarray, int]:
    """Symmetric FastICA with tanh nonlinearity; no ICA package is used."""
    n_components, n_samples = z.shape
    rng = np.random.default_rng(random_state)
    w = symmetric_decorrelation(rng.normal(size=(n_components, n_components)))
    for iteration in range(1, max_iter + 1):
        wz = w @ z
        g = np.tanh(wz)
        gp = 1.0 - g ** 2
        w_new = (g @ z.T) / n_samples - np.diag(np.mean(gp, axis=1)) @ w
        w_new = symmetric_decorrelation(w_new)
        # Sign-invariant convergence test.
        lim = np.max(np.abs(np.abs(np.diag(w_new @ w.T)) - 1.0))
        w = w_new
        if lim < tol:
            return w, iteration
    return w, max_iter


def best_match(separated: np.ndarray, sources: np.ndarray) -> tuple[list[int], np.ndarray]:
    """Find component permutation maximizing sum of absolute correlations."""
    k = sources.shape[0]
    corr = np.zeros((k, k), dtype=float)
    for i in range(k):
        for j in range(k):
            a, b = separated[i], sources[j]
            if np.std(a) < 1e-12 or np.std(b) < 1e-12:
                corr[i, j] = 0.0
            else:
                corr[i, j] = np.corrcoef(a, b)[0, 1]
    perm = max(itertools.permutations(range(k)), key=lambda p: sum(abs(corr[i, p[i]]) for i in range(k)))
    return list(perm), corr


def scale_aligned_sdr(reference: np.ndarray, estimate: np.ndarray) -> float:
    """Scale-align estimate to reference, then compute educational SDR in dB."""
    ref = reference - np.mean(reference)
    est = estimate - np.mean(estimate)
    denom = float(np.dot(est, est))
    if denom < 1e-15:
        return float("-inf")
    alpha = float(np.dot(ref, est) / denom)
    target = alpha * est
    noise = ref - target
    ratio = float(np.dot(target, target)) / max(float(np.dot(noise, noise)), 1e-15)
    return float(10 * np.log10(max(ratio, 1e-15)))


def plot_results(sources: np.ndarray, mixtures: np.ndarray, separated: np.ndarray,
                 source_names: list[str], corr: np.ndarray, metrics: dict) -> None:
    plots = OUT / "plots"
    plots.mkdir(parents=True, exist_ok=True)
    seconds = min(2.0, sources.shape[1] / SAMPLE_RATE)
    n = int(seconds * SAMPLE_RATE)
    t = np.arange(n) / SAMPLE_RATE
    fig, axes = plt.subplots(3, 1, figsize=(12, 8), constrained_layout=True)
    for i, ax in enumerate(axes):
        ax.plot(t, sources[i, :n], label=f"Original: {source_names[i]}", linewidth=0.8)
        ax.plot(t, mixtures[i, :n], label=f"Mixture channel {i+1}", alpha=0.65, linewidth=0.7)
        ax.set_ylabel("Amplitude")
        ax.legend(loc="upper right", fontsize=8)
    axes[-1].set_xlabel("Time (s)")
    fig.suptitle("Original sources and mixed channels (first 2 seconds)")
    fig.savefig(plots / "sources_vs_mixtures.png", dpi=150)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(7, 6), constrained_layout=True)
    im = ax.imshow(np.abs(corr), vmin=0, vmax=1, cmap="viridis")
    ax.set_xlabel("Original source index")
    ax.set_ylabel("Separated component index")
    ax.set_title("Absolute correlation: separated components vs originals")
    fig.colorbar(im, ax=ax, label="|correlation|")
    fig.savefig(plots / "correlation_matrix.png", dpi=150)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(10, 5), constrained_layout=True)
    labels = [m["source"] for m in metrics["per_source"]]
    values = [m["absolute_correlation"] for m in metrics["per_source"]]
    ax.bar(labels, values)
    ax.set_ylim(0, 1.05)
    ax.set_ylabel("Absolute correlation")
    ax.set_title("ICA separation quality after best source matching")
    ax.tick_params(axis="x", rotation=15)
    fig.savefig(plots / "quality_metrics.png", dpi=150)
    plt.close(fig)


def main():
    global SAMPLE_RATE
    parser = argparse.ArgumentParser(description="Mix audio sources and separate them with hand-written FastICA.")
    parser.add_argument("--custom", action="store_true", help="Load 2–5 WAV files from custom_sources/")
    parser.add_argument("--sample-rate", type=int, default=SAMPLE_RATE)
    parser.add_argument("--duration", type=int, default=DURATION_SECONDS, help="Duration in seconds for generated sources")
    parser.add_argument("--seed", type=int, default=RNG_SEED)
    args = parser.parse_args()
    SAMPLE_RATE = args.sample_rate

    if args.custom:
        sources, names = load_custom_sources(ROOT / "custom_sources", SAMPLE_RATE)
    else:
        sources, names = make_synthetic_sources(SAMPLE_RATE, args.duration)

    n_sources, n_samples = sources.shape
    rng = np.random.default_rng(args.seed)
    # Generate a well-conditioned custom mixing matrix and reject ill-conditioned draws.
    for _ in range(100):
        mixing = rng.uniform(0.3, 1.2, size=(n_sources, n_sources))
        mixing += np.eye(n_sources) * 0.8
        if np.linalg.cond(mixing) < 20:
            break
    else:
        raise RuntimeError("Could not create a well-conditioned mixing matrix.")

    mixtures = mixing @ sources
    mixtures -= mixtures.mean(axis=1, keepdims=True)
    mixtures /= np.maximum(np.max(np.abs(mixtures), axis=1, keepdims=True), 1e-12)
    z, whitening, centered_mixtures = pca_whiten(mixtures)
    w, iterations = fastica_from_scratch(z)
    separated = w @ z

    # Match each estimated component to a reference source, allowing permutation/sign/scale.
    permutation, corr = best_match(separated, sources)
    ordered = np.zeros_like(separated)
    per_source = []
    for component_index, source_index in enumerate(permutation):
        ordered[source_index] = separated[component_index]
    # Recompute component-source correlations in source order.
    for i, name in enumerate(names):
        a, b = ordered[i], sources[i]
        correlation = float(np.corrcoef(a, b)[0, 1]) if np.std(a) > 1e-12 and np.std(b) > 1e-12 else 0.0
        per_source.append({
            "source": name,
            "absolute_correlation": abs(correlation),
            "signed_correlation": correlation,
            "scale_aligned_sdr_db": scale_aligned_sdr(b, a),
        })

    # Export layout.
    for folder in ("sources", "mixtures", "separated", "plots"):
        (OUT / folder).mkdir(parents=True, exist_ok=True)
    for i, name in enumerate(names):
        save_wav(OUT / "sources" / f"{name}.wav", sources[i])
        save_wav(OUT / "mixtures" / f"mixture_{i+1}.wav", mixtures[i])
        save_wav(OUT / "separated" / f"separated_{name}.wav", normalize_audio(ordered[i]))
    metrics = {
        "sample_rate": SAMPLE_RATE,
        "samples": int(n_samples),
        "duration_seconds": n_samples / SAMPLE_RATE,
        "source_count": n_sources,
        "fastica_iterations": iterations,
        "mixing_matrix": mixing.tolist(),
        "per_source": per_source,
        "mean_absolute_correlation": float(np.mean([x["absolute_correlation"] for x in per_source])),
        "mean_scale_aligned_sdr_db": float(np.mean([x["scale_aligned_sdr_db"] for x in per_source])),
        "notes": "Metrics account for source permutation and sign/scale ambiguity; SDR is an educational scale-aligned metric."
    }
    (OUT / "metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    plot_results(sources, mixtures, ordered, names, corr, metrics)

    print("\nICA finished.")
    print(f"Sources: {n_sources} | Samples: {n_samples} | FastICA iterations: {iterations}")
    print(f"Mean |correlation|: {metrics['mean_absolute_correlation']:.3f}")
    print(f"Mean scale-aligned SDR: {metrics['mean_scale_aligned_sdr_db']:.2f} dB")
    print(f"Results saved in: {OUT}")
    for item in per_source:
        print(f"  {item['source']}: |corr|={item['absolute_correlation']:.3f}, SDR={item['scale_aligned_sdr_db']:.2f} dB")


if __name__ == "__main__":
    main()
