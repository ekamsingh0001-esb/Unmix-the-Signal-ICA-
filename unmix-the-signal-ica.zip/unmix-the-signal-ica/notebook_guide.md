# Notebook guide

To turn this into a notebook, create `ICA_Experiment.ipynb` in VS Code/Jupyter and use these sections:

1. Imports and reproducibility seed.
2. Load/generate independent sources.
3. Plot original sources.
4. Define custom mixing matrix and form mixtures.
5. Center mixtures and inspect covariance.
6. Eigen-decompose covariance and implement PCA whitening.
7. Implement symmetric decorrelation.
8. Implement FastICA fixed-point iteration with `tanh`.
9. Recover sources and plot waveforms.
10. Match sources by maximum absolute correlation; report correlation and scale-aligned SDR.
11. Compare PCA-only outputs against ICA outputs.
12. Discuss assumptions, failure modes, SNR, and permutation/sign/scale ambiguity.

The executable `run_ica.py` contains all the numerical code for these steps and produces plots automatically.
